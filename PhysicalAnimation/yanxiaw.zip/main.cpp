//
//  main.cpp
//  PhysicalAnimation
//
//  Created by Julian Wu on 8/23/12.
//  Copyright (c) 2012 Julian Wu. All rights reserved.
//

//  Style comments
//  Cooresponding header file here

//  C stdlib here

//  C++ stdlib here
#include <iostream>

//  3rt party header here
#include "Vector.h"
#include "Camera.h"

#ifdef __APPLE__
#  include <GLUT/glut.h>
#else
#  include <GL/glut.h>
#endif

//  project header here

//  Definitions and namespace
#include"definitions.h"
#include "object_drawer.h"
using namespace std;

#define WIDTH	    1024	/* window dimensions */
#define HEIGHT		768

Camera *camera;
bool showGrid = true;
int persp_win;


//void DrawABall(int collision,
//               void* obj);
//----------------------Including and definitions end-----------------------

//-------------------------------------------------------------------------
// Calculates the frames per second
//-------------------------------------------------------------------------
void calculateFPS()
{
  //  Increase frame count
  frameCount++;
  
  //  Get the number of milliseconds since glutInit called
  //  (or first call to glutGet(GLUT ELAPSED TIME)).
  currentTime = glutGet(GLUT_ELAPSED_TIME);
  
  //  Calculate time passed
  int timeInterval = currentTime - previousTime;
  
  if(timeInterval > 1000)
  {
    //  calculate the number of frames per second
    fps = frameCount / (timeInterval / 1000.0f);
    
    //  Set time
    previousTime = currentTime;
    
    //  Reset frame count
    frameCount = 0;
  }
  
//  printf("FPS: %f\n", fps);
}

// draws a simple grid
void makeGrid() {
  glColor3f(0.0, 0.0, 0.0);
  
  glLineWidth(1.0);
  
  for (float i=-12; i<12; i++) {
    for (float j=-12; j<12; j++) {
      glBegin(GL_LINES);
      glVertex3f(i, 0, j);
      glVertex3f(i, 0, j+1);
      glEnd();
      glBegin(GL_LINES);
      glVertex3f(i, 0, j);
      glVertex3f(i+1, 0, j);
      glEnd();
      
      if (j == 11){
        glBegin(GL_LINES);
        glVertex3f(i, 0, j+1);
        glVertex3f(i+1, 0, j+1);
        glEnd();
      }
      if (i == 11){
        glBegin(GL_LINES);
        glVertex3f(i+1, 0, j);
        glVertex3f(i+1, 0, j+1);
        glEnd();
      }
    }
  }
  
  glLineWidth(2.0);
  glBegin(GL_LINES);
  glVertex3f(-12, 0, 0);
  glVertex3f(12, 0, 0);
  glEnd();
  glBegin(GL_LINES);
  glVertex3f(0, 0, -12);
  glVertex3f(0, 0, 12);
  glEnd();
  glLineWidth(1.0);
}

void init() {
  // set up camera
  // parameters are eye point, aim point, up vector
  camera = new Camera(Vector3d(0, 32, 27), Vector3d(0, 0, 0),
                      Vector3d(0, 1, 0));
  
  // grey background for window
  glClearColor(0.62, 0.62, 0.62, 0.0);
  glShadeModel(GL_SMOOTH);
  glDepthRange(0.0, 1.0);
  
  glEnable(GL_DEPTH_TEST);
  glEnable(GL_NORMALIZE);
}

void mouseEventHandler(int button, int state, int x, int y) {
  // let the camera handle some specific mouse events (similar to maya)
  camera->HandleMouseEvent(button, state, x, y);
}

void motionEventHandler(int x, int y) {
  // let the camera handle some mouse motions if the camera is to be moved
  camera->HandleMouseMotion(x, y);
  glutPostRedisplay();
}

void keyboardEventHandler(unsigned char key, int x, int y) {
  float move_step = 0.07;
  switch (key) {
    case 'r': case 'R':
      // reset the camera to its initial position
      camera->Reset();
      break;
    case 'f': case 'F':
      camera->SetCenterOfFocus(Vector3d(0, 0, 0));
      break;
    case 'g': case 'G':
      showGrid = !showGrid;
      break;
    case 'a': case 'A':
      obs2ctr.x -= move_step;
      break;
    case 'd': case 'D':
      obs2ctr.x += move_step;
      break;
    case 's': case 'S':
      obs2ctr.y -= move_step;
      break;
    case 'w': case 'W':
      obs2ctr.y += move_step;
      break;
    case 'z': case 'Z':
      obs2ctr.z += move_step;
      break;
    case 'x': case 'X':
      obs2ctr.z -= move_step;
      break;
    case 'q': case 'Q':	// q or esc - quit
    case 27:		// esc
      exit(0);
  }
  
  glutPostRedisplay();
}



//// simulation function that called in glIdle loop
void Simulate(){
//  ball2d.move(DrawABall, 0.1f, obbox);
//  ball3d.move(DrawSphere, 0.005f, obbox3d);
  particle_manager1.move_particles(0.03f, obs2ctr, obs2rad);
  
  calculateFPS();
  glutPostRedisplay();
  usleep(13000);
  //  sleep(1);
}

void drawParticleGenerationPlane(){
  glColor4f(1.0, 1.0, 1.0, 0.2);
  Vector3d* genP = particle_manager1.generation_plane();
  glBegin(GL_QUADS);
  glVertex3f(genP[0].x, genP[0].y, genP[0].z );
//  glColor4f(0.0, 1.0, 0.0, 0.5);
  glVertex3f(genP[1].x, genP[1].y, genP[1].z );
//  glColor4f(0.0, 0.0, 1.0, 0.5);
  glVertex3f(genP[2].x, genP[2].y, genP[2].z );
  glVertex3f(genP[3].x, genP[3].y, genP[3].z );
  glEnd() ;
}


/*
 On Redraw request, erase the window and redraw everything
 */
void RenderScene(){
  
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  camera->PerspectiveDisplay(WIDTH, HEIGHT);
  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();
  if (showGrid)
    makeGrid();
  draw_obstancles(&obs2ctr);
  drawParticleGenerationPlane();
  draw_particles(particle_manager1.particles());
  //draw scene
//  glTranslatef(0, 3.5, 0);
//  Draw3DWorld();
//  glutWireTeapot(5);
  
  glutSwapBuffers();
  
}


// set up something in the world
void init_the_world() {
  
}

/*
 Load parameter file and reinitialize global parameters
 */
void LoadParameters(char *filename){
  
  FILE *paramfile;
  
  if((paramfile = fopen(filename, "r")) == NULL){
    fprintf(stderr, "error opening parameter file %s\n", filename);
    exit(1);
  }
  
  ParamFilename = filename;
  double Mass, v0x, v0y, v0z, drag, elastic, time_step, vwx, vwy, vwz, disp_time;
  if(fscanf(paramfile, "%lf %lf %lf %lf %lf %lf %lf %lf %lf %lf %lf",
            &Mass, &v0x, &v0y, &v0z, &drag, &elastic,
            &time_step, &disp_time, &vwx, &vwy, &vwz) != 11){
    fprintf(stderr, "error reading parameter file %s\n", filename);
    fclose(paramfile);
    exit(1);
  }
}

static char* parafile;
void Reset(){
  LoadParameters(parafile);
}


/*
 Main program to draw the square, change colors, and wait for quit
 */
int main(int argc, char* argv[]){
//  if(argc != 2){
//    fprintf(stderr, "usage: bounce paramfile\n");
//    exit(1);
//  }
//  LoadParameters(argv[1]);
//  parafile = argv[1];
  init_the_world();
  printf("R reset camera\nG toggle grid\nASWDZX move ball\nQ quit");
  
  // start up the glut utilities
  glutInit(&argc, argv);
  
  
  // make GLUT select a double buffered display that uses RGBA colors
  // Julian: Add GLUT_DEPTH when in 3D program so that 3D objects drawed
  // correctly regardless the order they draw
  glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
  glutInitWindowSize(WINDOW_WIDTH, WINDOW_HEIGHT);
//  glutInitWindowPosition(50, 50);
  persp_win = glutCreateWindow(window_title);
  
  // initialize the camera and such
  init();
  
  
  // set up the callback routines to be called when glutMainLoop() detects
  // an event
//  glutReshapeFunc(doReshape);
  glutDisplayFunc(RenderScene);
  glutMouseFunc(mouseEventHandler);
  glutMotionFunc(motionEventHandler);
  glutKeyboardFunc(keyboardEventHandler);
  glutIdleFunc(Simulate);
  
  
  /* Set shading to flat shading */
//  glShadeModel(GL_FLAT);

//  MakeMenu();
  
  // Routine that loops forever looking for events. It calls the registered
  // callback routine to handle each event that is detected
  glutMainLoop();
  return 0;
}
